##################################################
## Description: Example how to read richness data
## stored Richness Richness Patterns
## 
## Date: 2019-05-11 19:29:24
## Author: Oskar Hagen (oskar@hagen.bio)
##################################################

#load library
library(raster)
library(rgdal)

#define richness directory
rd <- "PLACE YOUR DIRECTORY HERE"

#define projections
projpol <- CRS("+init=epsg:3995 +proj=stere +lat_0=90 +lat_ts=71 +lon_0=0 +k=1 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs +ellps=WGS84 +towgs84=0,0,0") #+init=epsg:3995 +proj=stere +lat_0=90 +lat_ts=71 +lon_0=0 +k=1 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs +ellps=WGS84 +towgs84=0,0,0 


#read tif

#species richness
ca_s <- raster(file.path(rd, "cold-adapted_species.tif"))

#genera richness
ca_g <- raster(file.path(rd, "cold-adapted_genera.tif"))

#families

#list rasters of families
fam_files <- list.files(rd, pattern='cold-adapted_family_', full.names=T)
ca_f <- stack(fam_files)


###################################################################
#simple example on how to plot richness patterns (species richness)
##################################################################

#load ocean layer
ocean <- readOGR(file.path(rd,"ocean_layer/ocean.shp"))
#crop ocean
ocean <- crop(ocean, extent(-180, 180, -25, 90))
#transform into polar centered projection
ocean <- spTransform(ocean, CRSobj = projpol)
# transform to spatial polygon
ocean <- SpatialPolygons(ocean@polygons)
proj4string(ocean) <- projpol

#get maximum species richness per cell
sp_max <- max(values(ca_s), na.rm = T)

#transform raster
ca_s_pol <- projectRaster(ca_s, crs = projpol)

cols <- colorRampPalette(c("#74add1", "#e0f3f8", "#fdae61", "#f46d43", "#a50026"), bias = 0.9)(sp_max)
# add white for color for 0 species
cols <- c("white", cols)

par(mar = c(5.1, 4.5, 2.1, 1.1))
#plot richness
plot(ca_s_pol, col = cols, axes = F, box = F, legend = F)
#plot ocean
plot(ocean, add = T, col = "#1F407A", border = NA)
plot(ca_s_pol, col = cols, legend.only = T, horizontal = T, lwd = 0.02, 
       axis.args = list(at = seq(0, 600, 200), labels = seq(0, 600, 200), cex.axis = 0.6))